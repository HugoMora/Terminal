package com.terminal;


import static org.junit.Assert.assertNotNull;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import com.terminal.entity.Cliente;
import com.terminal.excepcion.ResourceNotFoundException;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TerminalApplicationTests {

	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	public void testClienteRegistrar() {

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String fechaCorta = "13/-13/1990";
		Date fecha = null;
		try {
			fecha = sdf.parse(fechaCorta);
		} catch (ParseException e) { // TODO Auto-generated catch block
			e.printStackTrace();
		}

		Cliente cliente = new Cliente();
		cliente.setNombre("Sarita");
		cliente.setApellido("Huacho");
		cliente.setDireccion("San Miguel");
		cliente.setDni("46541184");
		cliente.setFechaNacimiento(fecha);
		cliente.setTelefono("954112469");
		cliente.setCorreo("saritahuacho@gmail.com");
		cliente.setReferencia("Cliente de cineplanet");
		cliente.setEstado("A");

		ResponseEntity<Cliente> entidad = restTemplate.postForEntity("http://localhost:8080/terminal/cliente", cliente,
				Cliente.class);

		assertNotNull(entidad);
	}

	@Test
	public void tesClienteEliminar() throws Exception {	
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String fechaCorta = "13/13/1990";
		Date fecha = null;
		try {
			fecha = sdf.parse(fechaCorta);
		} catch (ParseException e) { // TODO Auto-generated catch block
			e.printStackTrace();
		}
		Cliente cliente = new Cliente();
		cliente.setNombre("Hugo");
		cliente.setApellido("Mora");
		cliente.setDireccion("San Miguel");
		cliente.setDni("46388284");
		cliente.setFechaNacimiento(fecha);
		cliente.setTelefono("971514071");
		cliente.setCorreo("HugoMora@gmail.com");
		cliente.setReferencia("Cliente de Zegel");
		cliente.setEstado("I");
		ResponseEntity<Cliente> response = restTemplate.postForEntity("http://localhost:8080/terminal/cliente", cliente, Cliente.class);  
        final String entityUrl = "http://localhost:8080/terminal/cliente" + "/" + response.getBody().getCodigo();               
        boolean thrown = false;
        try {
        	restTemplate.delete(entityUrl);
        } catch (ResourceNotFoundException e) {
          thrown = true;
        }
        assertNotNull(thrown);
	}

}
