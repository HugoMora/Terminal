package com.terminal.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.terminal.entity.Cliente;

public interface ClienteRepository extends CrudRepository<Cliente, Long> {
	
	@Query(value = "select codigo,apellido,correo,direccion,dni,estado,fecha_nacimiento,nombre,referencia,telefono from cliente where dni = ?1", nativeQuery = true)
	 Cliente findDataByDni(String dni);
	
	@Query(value = "select codigo,apellido,correo,direccion,dni,estado,fecha_nacimiento,nombre,referencia,telefono from cliente where codigo = ?1", nativeQuery = true)
	  Cliente findDataByCodigo(Long codigo);

	@Query(value = "select codigo,apellido,correo,direccion,dni,estado,fecha_nacimiento,nombre,referencia,telefono from "
			+ "cliente where codigo = ?1 and estado = 'A'", nativeQuery = true)
	  Cliente findStateByCodigo(Long codigo);
	

}
