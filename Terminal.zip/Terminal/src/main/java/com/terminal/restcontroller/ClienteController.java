package com.terminal.restcontroller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.terminal.excepcion.ResourceNotFoundException;
import com.terminal.entity.Cliente;
import com.terminal.repository.ClienteRepository;

@RestController
@RequestMapping("/terminal")
public class ClienteController {

	@Autowired
	private ClienteRepository clienteRepository;
	
	@GetMapping("/clientes")
	public List<Cliente> obtenerClientes(){		
		return(List<Cliente>) clienteRepository.findAll();
	}

	@GetMapping("/clientes/buscarDni/{dni}")
	public Cliente obtenerDni(@PathVariable(value = "dni") String dni) {
		return clienteRepository.findDataByDni(dni);
	}
	
	@GetMapping("/cliente/{codigo}")
	public Cliente obtenerCodigo(@PathVariable(value = "codigo") Long codigo) {
		return clienteRepository.findDataByCodigo(codigo);
	}
	
	@PostMapping("/cliente")
	public Cliente crearCliente(@Valid @RequestBody Cliente cliente) {

		return clienteRepository.save(cliente);
	}
	
	@DeleteMapping("/cliente/{codigo}")
	public ResponseEntity<String> borrarCliente(@PathVariable(value = "codigo") Long codigo) {
		Cliente cliente = clienteRepository.findStateByCodigo(codigo);
		
		if (cliente == null) {
			throw new ResourceNotFoundException("Cliente", "codigo", codigo);
		} else {
			clienteRepository.delete(cliente);
		}
			
		return ResponseEntity.ok().build();
		
	}

}
